package ui;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import model.User;
import model.Question;

public class QuizUI extends JFrame {

    private Question[] questions = {
        new Question("What is the capital of India?", new String[]{"Delhi", "Mumbai", "Kolkata", "Chennai"}, "Delhi"),
        new Question("Which planet is known as the Red Planet?", new String[]{"Earth", "Mars", "Jupiter", "Venus"}, "Mars"),
        new Question("Who is the founder of Microsoft?", new String[]{"Steve Jobs", "Bill Gates", "Mark Zuckerberg", "Elon Musk"}, "Bill Gates"),
        new Question("What is the largest mammal?", new String[]{"Elephant", "Blue Whale", "Giraffe", "Hippopotamus"}, "Blue Whale")
    };

    private int currentQuestion = 0;
    private int score = 0;

    private JLabel questionLabel;
    private JRadioButton[] optionButtons;
    private ButtonGroup optionsGroup;
    private JButton nextButton;
    private JButton submitButton;
    private JLabel welcomeLabel;

    private Map<Question, String> userAnswers = new LinkedHashMap<>();
    private User user;

    public QuizUI(User user) {
        this.user = user;

        setTitle("Quiz App");
        setSize(550, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // North panel with welcome
        JPanel topPanel = new JPanel(new BorderLayout());
        welcomeLabel = new JLabel("Welcome, " + user.getUsername() + "!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        topPanel.add(welcomeLabel, BorderLayout.NORTH);

        questionLabel = new JLabel("", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        topPanel.add(questionLabel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // Center panel with options
        JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        optionButtons = new JRadioButton[4];
        optionsGroup = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setFont(new Font("Arial", Font.PLAIN, 14));
            optionsGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        add(optionsPanel, BorderLayout.CENTER);

        // South panel with buttons
        JPanel buttonPanel = new JPanel();
        nextButton = new JButton("Next");
        submitButton = new JButton("Submit");
        submitButton.setEnabled(false);
        buttonPanel.add(nextButton);
        buttonPanel.add(submitButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Next button action
        nextButton.addActionListener(e -> {
            if (!isOptionSelected()) {
                JOptionPane.showMessageDialog(this, "Please select an option.");
                return;
            }
            storeAnswer();
            currentQuestion++;
            if (currentQuestion < questions.length) {
                loadQuestion();
                if (currentQuestion == questions.length - 1) {
                    nextButton.setEnabled(false);
                    submitButton.setEnabled(true);
                }
            }
        });

        // Submit button action
        submitButton.addActionListener(e -> {
            if (!isOptionSelected()) {
                JOptionPane.showMessageDialog(this, "Please select an option.");
                return;
            }
            storeAnswer();
            calculateScore();
            dispose();
            new ResultUI(score, questions.length, userAnswers);
        });

        loadQuestion();
        setVisible(true);
    }

    private void loadQuestion() {
        optionsGroup.clearSelection();
        Question q = questions[currentQuestion];
        questionLabel.setText("Q" + (currentQuestion + 1) + ": " + q.getQuestion());
        String[] opts = q.getOptions();
        for (int i = 0; i < opts.length; i++) {
            optionButtons[i].setText(opts[i]);
        }
    }

    private boolean isOptionSelected() {
        for (JRadioButton btn : optionButtons) {
            if (btn.isSelected()) return true;
        }
        return false;
    }

    private void storeAnswer() {
        Question q = questions[currentQuestion];
        for (JRadioButton btn : optionButtons) {
            if (btn.isSelected()) {
                userAnswers.put(q, btn.getText());
                break;
            }
        }
    }

    private void calculateScore() {
        score = 0;
        for (Map.Entry<Question, String> entry : userAnswers.entrySet()) {
            if (entry.getKey().getCorrectOption().equals(entry.getValue())) {
                score++;
            }
        }
    }
}
