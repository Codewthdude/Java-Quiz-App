package ui;

import javax.swing.*;
import dao.UserDAO;
import model.User;

public class RegisterUI extends JFrame {
    public RegisterUI() {
        setTitle("User Registration");
        setSize(300, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(100, 20, 160, 25);
        panel.add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(10, 60, 80, 25);
        panel.add(passLabel);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(100, 60, 160, 25);
        panel.add(passField);

        JCheckBox isAdmin = new JCheckBox("Admin");
        isAdmin.setBounds(100, 90, 100, 25);
        panel.add(isAdmin);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(100, 130, 100, 25);
        panel.add(registerButton);

        // Register button action
        registerButton.addActionListener(e -> {
            String username = userText.getText().trim();
            String password = new String(passField.getPassword()).trim();
            boolean admin = isAdmin.isSelected();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username and password are required.");
                return;
            }

            try {
                User user = new User();
                user.setUsername(username);
                user.setPassword(password);
                user.setAdmin(admin);
                boolean success = UserDAO.registerUser(user);
                if (success) {
                    JOptionPane.showMessageDialog(this, "✅ Registration successful! You can now log in.");
                    dispose(); 
                } else {
                    JOptionPane.showMessageDialog(this, "⚠ Registration failed. Try another username.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
            }
        });

        setVisible(true);
    }
}
