package ui;

import model.Question;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

public class ResultUI extends JFrame {

    public ResultUI(int score, int total, Map<Question, String> userAnswers) {
        setTitle("Quiz Result");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel scoreLabel = new JLabel("Your Score: " + score + "/" + total);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(scoreLabel);

        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); 

        
        for (Map.Entry<Question, String> entry : userAnswers.entrySet()) {
            Question q = entry.getKey();
            String userAnswer = entry.getValue();
            String correctAnswer = q.getCorrectOption();

            JPanel questionPanel = new JPanel();
            questionPanel.setLayout(new BoxLayout(questionPanel, BoxLayout.Y_AXIS));
            questionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            questionPanel.setBackground(Color.white);

            JLabel questionText = new JLabel("Q: " + q.getQuestion());
            questionText.setFont(new Font("Arial", Font.BOLD, 14));
            questionPanel.add(questionText);

            JLabel userAnsLabel = new JLabel("Your Answer: " + userAnswer);
            if (userAnswer.equals(correctAnswer)) {
                userAnsLabel.setForeground(new Color(0, 128, 0)); 
            } else {
                userAnsLabel.setForeground(Color.RED);
            }

            JLabel correctAnsLabel = new JLabel("Correct Answer: " + correctAnswer);
            correctAnsLabel.setForeground(Color.BLUE);

            questionPanel.add(userAnsLabel);
            questionPanel.add(correctAnsLabel);

            panel.add(Box.createRigidArea(new Dimension(0, 10)));
            panel.add(questionPanel);
        }

        add(scrollPane);
        setVisible(true);
    }
}
