package dao;

import java.sql.*;
import java.util.*;
import model.Question;
import utils.DBConnection;

public class QuestionDAO {

    public static List<Question> getAllQuestions() throws Exception {
        List<Question> list = new ArrayList<>();

        String sql = "SELECT * FROM questions";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Question q = new Question();
                q.setId(rs.getInt("id"));
                q.setQuestion(rs.getString("question"));
                q.setOptionA(rs.getString("optionA"));
                q.setOptionB(rs.getString("optionB"));
                q.setOptionC(rs.getString("optionC"));
                q.setOptionD(rs.getString("optionD"));
                q.setCorrectOption(rs.getString("correctOption"));
                list.add(q);
            }
        }

        return list;
    }
}
