package dao;

import java.sql.*;
import model.User;
import utils.DBConnection;
import utils.PasswordUtils;

public class UserDAO {

    public static User login(String username, String password) throws Exception {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        
        try (Connection con = DBConnection.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, PasswordUtils.hashPassword(password)); // hash input password

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setAdmin(rs.getBoolean("isAdmin"));
                return user;
            }
        }
        return null; 
    }

    public static boolean registerUser(User user) throws Exception {
        String sql = "INSERT INTO users(username, password, isAdmin) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, PasswordUtils.hashPassword(user.getPassword()));
            ps.setBoolean(3, user.isAdmin());
            return ps.executeUpdate() > 0;
        }
    }
}
