package model;

public class Question {
    private int id;
    private String question;
    private String[] options = new String[4];
    private String correctOption;

    // ✅ Required Constructor for hardcoded questions
    public Question(String question, String[] options, String correctOption) {
        this.question = question;
        this.options = options;
        this.correctOption = correctOption;
    }

    // Default constructor for database use
    public Question() {}

    // Getters
    public int getId() { return id; }
    public String getQuestion() { return question; }
    public String[] getOptions() { return options; }
    public String getCorrectOption() { return correctOption; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setQuestion(String question) { this.question = question; }
    public void setOptionA(String optionA) { this.options[0] = optionA; }
    public void setOptionB(String optionB) { this.options[1] = optionB; }
    public void setOptionC(String optionC) { this.options[2] = optionC; }
    public void setOptionD(String optionD) { this.options[3] = optionD; }
    public void setCorrectOption(String correctOption) { this.correctOption = correctOption; }
}
